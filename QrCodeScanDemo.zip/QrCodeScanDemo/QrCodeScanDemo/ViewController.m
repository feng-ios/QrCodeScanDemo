//
//  ViewController.m
//  QrCodeScanDemo
//
//  Created by 林豪威尔 on 2017/11/6.
//  Copyright © 2017年 PFYH. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>//原生二维码扫描必须导入这个框架
#import "AppDelegate.h"




@interface ViewController ()<AVCaptureMetadataOutputObjectsDelegate,UIAlertViewDelegate>
@property (nonatomic,strong)AVCaptureSession *session;
@property (nonatomic, strong) UILabel *indicateLabel;
@property (nonatomic, strong) UILabel *codeScanLabel;


@end

#define QRCodeWidth  260.0   //正方形二维码的边长
#define ScreenFullHeight [[UIScreen mainScreen] bounds].size.height  //屏幕高度
#define ScreenFullWidth [[UIScreen mainScreen] bounds].size.width     //屏幕宽度
#define COLOR_RGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBar.barTintColor = COLOR_RGB(0x333333);
    self.navigationItem.title = @"二维码";
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setupMaskView];//设置扫描区域之外的阴影视图
    
    [self setupScanWindowView];//设置扫描二维码区域的视图
    
    [self beginScanning];//开始扫二维码
    
}


- (void)setupMaskView
{
    //设置统一的视图颜色和视图的透明度
    UIColor *color = [UIColor blackColor];
    float alpha = 0.7;
    
    //设置扫描区域外部上部的视图
    UIView *topView = [[UIView alloc]init];
    topView.frame = CGRectMake(0, 64, ScreenFullWidth, (ScreenFullHeight-64-QRCodeWidth)/2.0-64);
    topView.backgroundColor = color;
    topView.alpha = alpha;
    
    //设置扫描区域外部左边的视图
    UIView *leftView = [[UIView alloc]init];
    leftView.frame = CGRectMake(0, 64+topView.frame.size.height, (ScreenFullWidth-QRCodeWidth)/2.0,QRCodeWidth);
    leftView.backgroundColor = color;
    leftView.alpha = alpha;
    
    //设置扫描区域外部右边的视图
    UIView *rightView = [[UIView alloc]init];
    rightView.frame = CGRectMake((ScreenFullWidth-QRCodeWidth)/2.0+QRCodeWidth,64+topView.frame.size.height, (ScreenFullWidth-QRCodeWidth)/2.0,QRCodeWidth);
    rightView.backgroundColor = color;
    rightView.alpha = alpha;
    
    //设置扫描区域外部底部的视图
    UIView *botView = [[UIView alloc]init];
    botView.frame = CGRectMake(0, 64+QRCodeWidth+topView.frame.size.height,ScreenFullWidth,ScreenFullHeight-64-QRCodeWidth-topView.frame.size.height);
    botView.backgroundColor = color;
    botView.alpha = alpha;
    //将设置好的扫描二维码区域之外的视图添加到视图图层上
    [self.view addSubview:topView];
    [self.view addSubview:leftView];
    [self.view addSubview:rightView];
    [self.view addSubview:botView];
    
    //将二维码或者条形码 放入框内 即可自动扫描
    _indicateLabel = [[UILabel alloc] init];
    _indicateLabel.backgroundColor = [UIColor clearColor];
    _indicateLabel.font = [UIFont systemFontOfSize:15];
    _indicateLabel.textColor = [UIColor whiteColor];
    _indicateLabel.textAlignment = NSTextAlignmentCenter;
    _indicateLabel.adjustsFontSizeToFitWidth = YES;
    [_indicateLabel sizeToFit];
    _indicateLabel.frame = CGRectMake(CGRectGetMaxX(leftView.frame), CGRectGetMinY(botView.frame)+15, CGRectGetMinX(rightView.frame)-CGRectGetMaxX(leftView.frame), 20);
    _indicateLabel.text = @"将二维码/条形码放入框内，即可自动扫描";
    [self.view addSubview:_indicateLabel];
    //我的二维码
    _codeScanLabel = [[UILabel alloc] init];
    _codeScanLabel.backgroundColor = [UIColor clearColor];
    _codeScanLabel.font = [UIFont systemFontOfSize:16];
    _codeScanLabel.textColor = COLOR_RGB(0x6fdc31);
    _codeScanLabel.textAlignment = NSTextAlignmentCenter;
    _codeScanLabel.frame = CGRectMake(CGRectGetMaxX(leftView.frame), CGRectGetMaxY(_indicateLabel.frame)+20, CGRectGetMinX(rightView.frame)-CGRectGetMaxX(leftView.frame), 20);
    _codeScanLabel.text = @"我的二维码";
    [self.view addSubview:_codeScanLabel];
    
}


- (void)setupScanWindowView
{
    //设置扫描区域的位置(考虑导航栏和电池条的高度为64)
    UIView *scanWindow = [[UIView alloc]initWithFrame:CGRectMake((ScreenFullWidth-QRCodeWidth)/2.0,(ScreenFullHeight-QRCodeWidth-64)/2.0,QRCodeWidth,QRCodeWidth)];
    scanWindow.clipsToBounds = YES;
    [self.view addSubview:scanWindow];
    
    //设置扫描区域的动画效果
    CGFloat scanNetImageViewH = 5;
    CGFloat scanNetImageViewW = scanWindow.frame.size.width;
    UIImageView *scanNetImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"qrcode_scan_line"]];
    scanNetImageView.frame = CGRectMake(0, -scanNetImageViewH, scanNetImageViewW, scanNetImageViewH);
    CABasicAnimation *scanNetAnimation = [CABasicAnimation animation];
    scanNetAnimation.keyPath =@"transform.translation.y";
    scanNetAnimation.byValue = @(QRCodeWidth);
    scanNetAnimation.duration = 2.0;
    scanNetAnimation.repeatCount = MAXFLOAT;
    [scanNetImageView.layer addAnimation:scanNetAnimation forKey:nil];
    [scanWindow addSubview:scanNetImageView];
    
    //设置扫描区域的四个角的边框
    UIImageView *backImageView = [[UIImageView alloc] init];
    backImageView.image = [UIImage imageNamed:@"qrcode_border_new"];
    backImageView.backgroundColor =[UIColor clearColor];
    backImageView.frame = scanWindow.bounds;
    [scanWindow addSubview:backImageView];
    
//    CGFloat buttonWH = 18;
//    UIButton *topLeft = [[UIButton alloc]initWithFrame:CGRectMake(0,0, buttonWH, buttonWH)];
//    [topLeft setImage:[UIImage imageNamed:@"scan_1"]forState:UIControlStateNormal];
//    [scanWindow addSubview:topLeft];
//
//    UIButton *topRight = [[UIButton alloc]initWithFrame:CGRectMake(QRCodeWidth - buttonWH,0, buttonWH, buttonWH)];
//    [topRight setImage:[UIImage imageNamed:@"scan_2"]forState:UIControlStateNormal];
//    [scanWindow addSubview:topRight];
//
//    UIButton *bottomLeft = [[UIButton alloc]initWithFrame:CGRectMake(0,QRCodeWidth - buttonWH, buttonWH, buttonWH)];
//    [bottomLeft setImage:[UIImage imageNamed:@"scan_3"]forState:UIControlStateNormal];
//    [scanWindow addSubview:bottomLeft];
//
//    UIButton *bottomRight = [[UIButton alloc]initWithFrame:CGRectMake(QRCodeWidth-buttonWH,QRCodeWidth-buttonWH, buttonWH, buttonWH)];
//    [bottomRight setImage:[UIImage imageNamed:@"scan_4"]forState:UIControlStateNormal];
//    [scanWindow addSubview:bottomRight];
}

- (void)beginScanning
{
    //获取摄像设备
    AVCaptureDevice * device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //创建输入流
    AVCaptureDeviceInput * input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    if (!input) return;
    //创建输出流
    AVCaptureMetadataOutput * output = [[AVCaptureMetadataOutput alloc]init];
    
    //特别注意的地方：有效的扫描区域，定位是以设置的右顶点为原点。屏幕宽所在的那条线为y轴，屏幕高所在的线为x轴
    CGFloat x = ((ScreenFullHeight-QRCodeWidth-64)/2.0)/ScreenFullHeight;
    CGFloat y = ((ScreenFullWidth-QRCodeWidth)/2.0)/ScreenFullWidth;
    CGFloat width = QRCodeWidth/ScreenFullHeight;
    CGFloat height = QRCodeWidth/ScreenFullWidth;
    output.rectOfInterest = CGRectMake(x, y, width, height);
    
    //设置代理在主线程里刷新
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    //初始化链接对象
    _session = [[AVCaptureSession alloc]init];
    //高质量采集率
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    
    [_session addInput:input];
    [_session addOutput:output];
    //设置扫码支持的编码格式(如下设置条形码和二维码兼容)
    output.metadataObjectTypes=@[AVMetadataObjectTypeQRCode,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeCode128Code];
    
    AVCaptureVideoPreviewLayer * layer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    layer.videoGravity=AVLayerVideoGravityResizeAspectFill;
    layer.frame=self.view.layer.bounds;
    [self.view.layer insertSublayer:layer atIndex:0];
    //开始捕获
    [_session startRunning];
    
}

/** 二维码 条形码 扫描结果*/
-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    if (metadataObjects.count>0) {
        [_session stopRunning];
        //得到二维码上的所有数据
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex:0];
        NSString *str = metadataObject.stringValue;
        UIAlertView *alertiew = [[UIAlertView alloc] initWithTitle:@"扫描结果" message:str delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        alertiew.delegate = self;
        [alertiew show];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
        NSLog(@"%@",str);
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
            [_session startRunning];
            break;
            
        case 1:
            [_session startRunning];
        default:
            break;
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
